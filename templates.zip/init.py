import shelve
import uuid
from flask import Flask, render_template, request, redirect, url_for, jsonify

app = Flask(__name__)

# Declare global variables
total = 0  # Adjust the initial value as needed
coupon_prompt = ''
coupons_used = set()
original_product_prices = {
    'product1': 19.90,
    'product2': 29.90,
}


# Dummy data for the shopping cart
products = {
    'product1': {
        'title': 'Graphic Tote Bag',
        'sizes': ['Medium'],
        'colour': ['-'],
        'quantity': 1,
        'image_url': 'https://cms.cloudinary.vpsvc.com/images/c_scale,dpr_auto,f_auto,q_60,w_235/legacy_dam/en-sg/S001532459/large-zip-cotton-tote-Bag-transparent-search-tile-001?cb=870d77dc01e888e9f9e8d6cfeba881215bc3b6d9'
    },
    'product2': {
        'title': 'Butterfly Friendship Necklace',
        'sizes': ['-'],
        'colour': ['Rose Gold'],
        'quantity': 1,
        'image_url': 'https://secretsisterhood.com/wp-content/uploads/2020/01/Butterfly_FH_RoseGold_crop_SS.jpg'
    }
}
product_prices = {
    'product1': 19.90,
    'product2': 29.90,
}

# Global variable for coupon data
coupon_data = {
    'coupons_used': [
        {'code': 'EARTH20', 'discount_percentage': 20},
        # Add the new coupon data
        {'code': 'REGLOW10', 'discount_percentage': 10},
    ]
}

product_prices_original = product_prices.copy()


# Update calculate_total_with_discount function
# Update calculate_total_with_discount function
def calculate_total_with_discount(products, product_prices, applied_coupon):
    total = 0
    for product_id, product in products.items():
        total += product_prices.get(product_id, 0) * product.get('quantity', 1)

    if applied_coupon:
        discount_percentage = next(
            (coupon['discount_percentage'] for coupon in coupon_data['coupons_used'] if coupon['code'] == applied_coupon), 0)
        total *= (100 - discount_percentage) / 100

    return round(total, 2)


@app.route('/validate_coupon', methods=['POST'])
def validate_coupon():
    try:
        data = request.get_json()
        coupon_code = data.get('coupon', '')

        # Assuming you have a list of valid coupon codes
        valid_coupons = ['EARTH20', 'REGLOW10']

        if coupon_code in valid_coupons:
            # Calculate the new total with the discount applied
            new_total = calculate_total_with_discount(products, product_prices, coupon_code)
            return jsonify({'valid': True, 'total': new_total})
        else:
            return jsonify({'valid': False, 'error': 'Invalid coupon code.'})

    except Exception as e:
        return jsonify({'valid': False, 'error': str(e)})


def apply_coupon_discount(products, product_prices, coupon_code, applied_coupon):
    if applied_coupon:
        return None, 'Only one coupon can be used at a time.'

    valid_coupons = [coupon['code'] for coupon in coupon_data['coupons_used']]
    if coupon_code not in valid_coupons:
        return None, 'Invalid coupon code.'

    discount_percentage = next(
        (coupon['discount_percentage'] for coupon in coupon_data['coupons_used'] if coupon['code'] == coupon_code), 0)

    # Store the applied coupon data
    with shelve.open('coupons.db', 'c', writeback=True) as db:
        coupons_used = db.get('coupons_used', [])
        coupons_used.append({'code': coupon_code, 'discount_percentage': discount_percentage})
        db['coupons_used'] = coupons_used

    print(f"Coupon {coupon_code} applied successfully!")
    print(f"Current coupons_used: {coupons_used}")

    discounted_prices = {product_id: product_prices[product_id] * (100 - discount_percentage) / 100
                         for product_id in product_prices}

    return discounted_prices, f'Coupon {coupon_code} applied successfully!'



@app.route('/shoppingcart', methods=['GET', 'POST'])
def shoppingcart():
    global products, product_prices, coupon_data, total, coupon_prompt, coupons_used

    template_data = {
        'products': products,
        'product_prices': product_prices,
        'total': calculate_total_with_discount(products, product_prices, None),
        'coupon_prompt': coupon_prompt,
    }

    coupon_error = None

    if request.method == 'POST':
        coupon_code = request.form.get('coupon_code')  # Retrieve the coupon code
        action = request.form.get('action')
        product_id = request.form.get('product_id')

        if action and product_id:
            if action == 'decrease':
                products[product_id]['quantity'] = max(0, products[product_id]['quantity'] - 1)
            elif action == 'increase':
                products[product_id]['quantity'] += 1
            elif action == 'remove':
                del products[product_id]  # Remove the product from the cart

        if coupon_code:
            valid_coupon = any(coupon['code'] == coupon_code for coupon in coupon_data['coupons_used'])
            if valid_coupon:
                applied_coupon = next(
                    (coupon['code'] for coupon in coupon_data['coupons_used'] if coupon['code'] == coupon_code), None)

                if not applied_coupon:
                    # Apply the coupon discount
                    product_prices, coupon_prompt = apply_coupon_discount(products, product_prices, coupon_code,
                                                                           applied_coupon)
                    total = calculate_total_with_discount(products, product_prices, coupon_code)
                else:
                    total = calculate_total_with_discount(products, product_prices, applied_coupon)
                    coupon_prompt = 'Another coupon is already applied. Only one coupon can be used at a time.'
            else:
                total = calculate_total_with_discount(products, product_prices, None)
                coupon_prompt = 'Invalid coupon code.'
        else:
            coupon_prompt = ''

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'total': total, 'coupon_prompt': template_data['coupon_prompt'],
                            'coupon_error': coupon_error})

    template_data['total'] = calculate_total_with_discount(template_data['products'], template_data['product_prices'],
                                                           None)
    return render_template('includes/shoppingcart.html', **template_data)


@app.route('/view_coupons')
def view_coupons():
    # Access the stored coupon data from shelve
    with shelve.open('coupons.db', 'r') as db:
        coupons_used = db.get('coupons_used', [])

    print(f"Current coupons_used: {coupons_used}")

    return render_template('includes/view_coupons.html', coupons_used=coupons_used)



@app.route('/remove_coupon/<string:coupon_code>', methods=['POST'])
def remove_coupon(coupon_code):
    global coupons_used, total, product_prices_original

    # Remove the coupon from the coupons_used list
    coupons_used = [coupon for coupon in coupons_used if coupon['code'] != coupon_code]

    # Reset product prices to original values
    product_prices = product_prices_original.copy()

    # Recalculate the total with the remaining coupons
    total = calculate_total_with_discount(products, product_prices, coupons_used)
    coupon_prompt = f'Coupon {coupon_code} removed.'

    return redirect(url_for('shoppingcart'))

@app.route('/remove_product', methods=['POST'])
def remove_product():
    global products, product_prices, total

    data = request.get_json()
    product_id = data.get('product_id')

    # Check if the product exists in the shopping cart
    if product_id in products:
        # Decrement the total by the price of the deleted product
        total -= product_prices.get(product_id, 0) * products[product_id]['quantity']

        # Remove the product from the shopping cart
        del products[product_id]

        # Update the product prices if needed
        product_prices = calculate_product_prices_with_discount(products, product_prices, None)

        # Recalculate the total with discounts applied
        total = calculate_total_with_discount(products, product_prices, None)

        # Return success response
        return jsonify({'success': True, 'total': total})
    else:
        # Return error response if the product is not found (optional)
        return jsonify({'success': False, 'error': 'Product not found'})



def calculate_product_prices_with_discount(products, product_prices, applied_coupon):
    discounted_prices = product_prices.copy()

    if applied_coupon:
        # Apply discount logic based on the coupon
        discount_percentage = get_discount_percentage_for_coupon(applied_coupon)  # Replace with your logic
        discounted_prices = {product_id: price * (100 - discount_percentage) / 100
                             for product_id, price in product_prices.items()}

    return discounted_prices

@app.route('/update_quantity', methods=['POST'])
def update_quantity():
    global products, product_prices, total

    if request.method == 'POST':
        action = request.form.get('action')
        product_id = request.form.get('product_id')

        if action == 'increase':
            # Increment quantity
            products[product_id]['quantity'] += 1
        elif action == 'decrease' and products[product_id]['quantity'] > 1:
            # Decrement quantity, but not below 1
            products[product_id]['quantity'] -= 1

        # Recalculate the total with discounts applied
        total = calculate_total_with_discount(products, product_prices, None)

        # Redirect back to the shopping cart page
        return redirect(url_for('shoppingcart'))

    # Handle the case where the request method is not POST (optional)
    return "Method Not Allowed", 405


@app.route('/')
def home():
    with shelve.open('reviews.db') as db:
        reviews = db.get('reviews', [])

    return render_template('index.html', reviews=reviews)


# Sustainability
@app.route('/sustainability')
def sustainability():
    return render_template('includes/sustainability.html', current_url=request.path)


# Membership
@app.route('/membership')
def membership():
    return render_template('includes/membership.html', current_url=request.path)


purchase_data = [
    {
        'product_id': 'product1',
        'title': 'Graphic Tote Bag',
        'order_id': '562368',
        'sku': '#5867234623598',
        'purchase_date': '05/01/2024',
        'product_picture': 'https://cms.cloudinary.vpsvc.com/images/c_scale,dpr_auto,f_auto,q_60,w_235/legacy_dam/en-sg/S001532459/large-zip-cotton-tote-Bag-transparent-search-tile-001?cb=870d77dc01e888e9f9e8d6cfeba881215bc3b6d9',
        'order_total': 19.90,
    },
    {
        'product_id': 'product2',
        'title': 'Butterfly Friendship Necklace',
        'order_id': '239165',
        'sku': '#97342187126721',
        'purchase_date': '05/01/2024',
        'product_picture': 'https://secretsisterhood.com/wp-content/uploads/2020/01/Butterfly_FH_RoseGold_crop_SS.jpg',
        'order_total': 29.90,
    },
]


# Existing route for purchase history
@app.route('/purchasehistory')
def purchasehistory():
    global purchase_data

    with shelve.open('reviews.db') as db:
        reviews = db.get('reviews', [])

    return render_template('includes/purchasehistory.html', purchase_data=purchase_data, reviews=reviews)


# New route to handle retrieve operation
@app.route('/retrieve_purchase_data', methods=['GET'])
def retrieve_purchase_data():
    # Add your logic for retrieve operation here (if needed)
    return "Retrieve Operation - To be implemented"


# New route to handle display operation
@app.route('/display_purchase_data', methods=['GET'])
def display_purchase_data():
    # Add your logic for display operation here (if needed)
    return "Display Operation - To be implemented"


# New route to handle delete operation
@app.route('/delete_purchase_data/<string:product_id>', methods=['GET'])
def delete_purchase_data(product_id):
    global purchase_data
    purchase_data = [item for item in purchase_data if item['product_id'] != product_id]
    return render_template('includes/purchasehistorydata.html', purchase_data=purchase_data)


# New route to handle the delete operation
@app.route('/delete_purchase/<string:product_id>', methods=['POST'])
def delete_purchase(product_id):
    # Your logic for deleting the purchase (replace with your backend logic)
    # For example, you might delete the purchase record from the database

    # Redirect back to the purchase history page after deletion
    return redirect(url_for('purchasehistory'))


class ContactForm:
    def __init__(self, first_name, last_name, email, contact, query, description):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.contact = contact
        self.query = query
        self.description = description


# Contact Us
@app.route('/contactus', methods=['GET', 'POST'])
def contact_us():
    validation_errors = {}  # Initialize the variable here

    if request.method == 'POST':
        # Retrieve form data
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        contact = request.form.get('contact')
        query = request.form.get('query')
        description = request.form.get('description')

        # Open the contactus.db file
        with shelve.open('contactus.db', 'c', writeback=True) as db:
            # Store data using a unique key (e.g., a UUID) as the key
            contact_id = str(uuid.uuid4())[:7]
            contact_data = db.get('contact_key', {})
            contact_data[contact_id] = {
                'first_name': first_name,
                'last_name': last_name,
                'email': email,
                'contact_number': contact,
                'query': query,
                'description': description
            }
            db['contact_key'] = contact_data

        # Redirect to the thank_you_review route after successful form submission
        return redirect(url_for('thank_you_review'))

    return render_template('includes/contactus.html', validation_errors=validation_errors)



# View stored contact data
@app.route('/view_contact_data')
def view_contact_data():
    try:
        # Open the shelve file
        with shelve.open('contactus.db', 'r') as db:
            # Access the stored data
            contact_data = db.get('contact_key', {})
            contacts = []
            for contact_id, contact_info in contact_data.items():
                contacts.append({
                    'contact_id': contact_id,
                    'first_name': contact_info['first_name'],
                    'last_name': contact_info['last_name'],
                    'email': contact_info['email'],
                    'contact_number': contact_info.get('contact_number', ''),  # Use .get() to handle missing key
                    'query': contact_info['query'],
                    'description': contact_info['description'],
                })

        return render_template('includes/viewcontactdata.html', contacts=contacts)

    except Exception as e:
        return f"Error: {str(e)}"


# Submit Review
@app.route('/submit_review', methods=['POST'])
def submit_review():
    if request.method == 'POST':
        # Handle the review submission logic
        rating = request.form['rating']
        review_text = request.form['review_text']

        with shelve.open('reviews.db') as db:
            reviews = db.get('reviews', [])
            reviews.append({'rating': int(rating), 'review_text': review_text})
            db['reviews'] = reviews

        # After submitting the review, redirect to the homepage
        return redirect(url_for('home'))

    return "Method Not Allowed", 405


# Thank You Review
@app.route('/thank_you_review')
def thank_you_review():
    return render_template('includes/thank_you_review.html')


@app.route('/termsnconditions')
def termsnconditions():
    return render_template('includes/termsnconditions.html')


# Run the application
if __name__ == '__main__':
    app.run(debug=True)